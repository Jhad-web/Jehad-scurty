const canvas = document.getElementById("virusCanvas");
const ctx = canvas.getContext("2d");
const scanButton = document.getElementById("scanButton");
const statusText = document.getElementById("status");

// تحميل أصوات المؤثرات
const scanSound = new Audio("scan.mp3");
const alertSound = new Audio("alert.mp3");

canvas.width = canvas.clientWidth;
canvas.height = 200;

function drawVirus(x, y) {
    ctx.fillStyle = "red";
    ctx.beginPath();
    ctx.arc(x, y, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
}

function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

function scanForViruses() {
    statusText.textContent = "🔄 جارٍ الفحص...";
    scanButton.disabled = true;

    // تشغيل صوت الفحص
    scanSound.play();

    setTimeout(() => {
        clearCanvas();
        let virusCount = Math.floor(Math.random() * 5);
        
        if (virusCount > 0) {
            alertSound.play(); // تشغيل صوت التحذير عند اكتشاف الفيروسات
            for (let i = 0; i < virusCount; i++) {
                let x = Math.random() * canvas.width;
                let y = Math.random() * canvas.height;
                drawVirus(x, y);
            }
            statusText.textContent = `🚨 تم العثور على ${virusCount} فيروسات!`;
        } else {
            statusText.textContent = "✅ الجهاز آمن تمامًا!";
        }

        scanButton.disabled = false;
    }, 2000);
}

scanButton.addEventListener("click", scanForViruses);